package com.cg.media.bean;

import java.sql.Date;

public class Song_Master

{
	private int song_id;
	private int artist_id;
	private int composer_id;
	private String song_name;
	private String song_duration;
	private int Created_by;
	private Date Created_on;
	private int Updated_by;
	private Date Updated_on;


	public int getSong_id() 
	{
		return song_id;
	}
	public void setSong_id(int song_id) 
	{
		this.song_id = song_id;
	}
	public String getSong_name() 
	{
		return song_name;
	}
	public void setSong_name(String song_name) 
	{
		this.song_name = song_name;
	}
	public String getSong_duration() 
	{
		return song_duration;
	}
	public void setSong_duration(String song_duration) 
	{
		this.song_duration = song_duration;
	}
	public int getCreated_by() 
	{
		return Created_by;
	}
	public void setCreated_by(int created_by) 
	{
		Created_by = created_by;
	}
	public Date getCreated_on() 
	{
		return Created_on;
	}
	public void setCreated_on(Date created_on) 
	{
		Created_on = created_on;
	}
	public int getUpdated_by() 
	{
		return Updated_by;
	}
	public void setUpdated_by(int updated_by) 
	{
		Updated_by = updated_by;
	}
	public Date getUpdated_on() 
	{
		return Updated_on;
	}
	public void setUpdated_on(Date updated_on) 
	{
		Updated_on = updated_on;
	}
	
	
	public int getArtist_id() {
		return artist_id;
	}
	public void setArtist_id(int artist_id) {
		this.artist_id = artist_id;
	}
	public int getComposer_id() {
		return composer_id;
	}
	public void setComposer_id(int composer_id) {
		this.composer_id = composer_id;
	}
	public Song_Master() {
		super();

	}
	
	

	public Song_Master(int song_id, int artist_id, int composer_id,
			String song_name, String song_duration, int created_by,
			Date created_on, int updated_by, Date updated_on) {
		super();
		this.song_id = song_id;
		this.artist_id = artist_id;
		this.composer_id = composer_id;
		this.song_name = song_name;
		this.song_duration = song_duration;
		Created_by = created_by;
		Created_on = created_on;
		Updated_by = updated_by;
		Updated_on = updated_on;
	}
	/*@Override
	public String toString() 
	{
		return "Song_Master [song_id=" + song_id + ", song_name=" + song_name
				+ ", song_duration=" + song_duration + ", Created_by="
				+ Created_by + ", Created_on=" + Created_on + ", Updated_by="
				+ Updated_by + ", Updadted_on=" + Updated_on + "]";
	}*/

	public String toString() 
	{
		return ""+ song_id + "\t\t" + song_name
				+ "\t\t" + song_duration;
	}


}
