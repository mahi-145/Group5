package com.cg.media.bean;

public class Admin_Master 
{

}
