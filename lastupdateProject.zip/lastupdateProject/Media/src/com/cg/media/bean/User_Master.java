package com.cg.media.bean;

public class User_Master
{

}
