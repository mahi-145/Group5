package com.cg.media.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.media.dto.Song_Master;
import com.cg.media.service.MediaService;

@Controller
public class MediaController 
{
	@Autowired
	MediaService mediaservice;
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
		
	}
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String operations()
	{
		return "mediaoperations";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addSong(Model model )
	{
		model.addAttribute("medi",new Song_Master());
		return "addsong";
		
	}
	
	@RequestMapping(value="insertData",method=RequestMethod.POST)
	public String insertdata(@ModelAttribute("medi") Song_Master sm)
	{
		mediaservice.addSongs(sm);
		return "success";
	}
}
