package com.cg.media.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.media.dto.Song_Master;

@Repository("mediadao")
public class MediaDaoImpl implements MediaDao 

{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public int addSongs(Song_Master sm) 
	{
		System.out.println("in addsongs");
		entitymanager.persist(sm);
		entitymanager.flush();
		return sm.getSongId();
	}
	
	
}
