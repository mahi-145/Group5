package com.cg.media.dao;

import com.cg.media.dto.Song_Master;

public interface MediaDao 
{

	public int addSongs(Song_Master sm);
	
}
