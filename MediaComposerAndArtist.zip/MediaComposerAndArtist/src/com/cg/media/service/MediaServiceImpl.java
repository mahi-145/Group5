package com.cg.media.service;

import javax.transaction.Transactional;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.media.dao.MediaDao;
import com.cg.media.dto.Song_Master;

@Service("mediaservice")
@Transactional
public class MediaServiceImpl implements MediaService 
{
	@Autowired
	MediaDao mediadao;

	@Override
	public int addSongs(Song_Master sm) 
	{
		
		return mediadao.addSongs(sm);
	}
	
}
