package com.cg.media.service;

import com.cg.media.dto.Song_Master;

public interface MediaService 
{

	public int addSongs(Song_Master sm);
	
}
