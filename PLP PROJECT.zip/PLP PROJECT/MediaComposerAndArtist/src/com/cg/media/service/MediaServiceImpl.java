package com.cg.media.service;

import java.util.List;

import javax.transaction.Transactional;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.media.dao.MediaDao;
import com.cg.media.dto.Song_Master;

@Service("mediaservice")
@Transactional
public class MediaServiceImpl implements MediaService 
{
	@Autowired
	MediaDao mediadao;

	@Override
	public int addSongs(Song_Master sm) 
	{
		
		return mediadao.addSongs(sm);
	}

	@Override
	public List<Song_Master> retrieveArtist(String artistName) 
	{
		
		return mediadao.retrieveArtist(artistName);
	}

	@Override
	public String getName(String artistName) {
		
		return mediadao.getName(artistName);
	}
	
}
