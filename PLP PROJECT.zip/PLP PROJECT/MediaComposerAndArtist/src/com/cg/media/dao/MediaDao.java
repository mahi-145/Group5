package com.cg.media.dao;

import java.util.List;

import com.cg.media.dto.Song_Master;

public interface MediaDao 
{

	public int addSongs(Song_Master sm);
	public List<Song_Master> retrieveArtist(String artistName);
	public String getName(String artistName);
}
