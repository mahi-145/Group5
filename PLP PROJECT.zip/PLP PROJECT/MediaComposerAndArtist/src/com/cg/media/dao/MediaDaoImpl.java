package com.cg.media.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.media.dto.Artist_Master;
import com.cg.media.dto.Song_Master;

@Repository("mediadao")
public class MediaDaoImpl implements MediaDao 

{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public int addSongs(Song_Master sm) 
	{
		
		entitymanager.persist(sm);
		entitymanager.flush();
		return sm.getSongId();
	}

	@Override
	public List<Song_Master> retrieveArtist(String artistName) 
	{
		Query queryone=entitymanager.createQuery("Select song from Song_Master song where artistName=:aname");
		queryone.setParameter("aname", artistName);
		return queryone.getResultList();
	}

	@Override
	public String getName(String artistName) 
	{
		Query queryone=entitymanager.createQuery("Select artistName from Song_Master where artistName=:aname");
		queryone.setParameter("aname", artistName);
		return (String) queryone.getSingleResult();
	}

	@Override
	public List<Artist_Master> retrieveAllArtist() 
	{
		Query querytwo = entitymanager.createQuery("FROM Artist_Master");
		return querytwo.getResultList();
	}
	
	
}
